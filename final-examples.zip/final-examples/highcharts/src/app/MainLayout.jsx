import React, { Component, lazy, Suspense } from 'react';
import { Route, Switch } from "react-router-dom";

import HighchartsMenu from "./components/navigation/presentation/HighchartsMenu";

import DashboardHome from "./components/dashboards/container/DashboardHome";
const DailyStock = lazy(() => import("./components/stocks/container/DailyStock"));
const MonthlyStockComparison = lazy(() => import("./components/stocks/container/MonthlyStockComparison"));
const WeeklyStock = lazy(() => import("./components/stocks/container/WeeklyStock"));
const MonthlyStock = lazy(() => import("./components/stocks/container/MonthlyStock"));
const FinalDashboard = lazy(() => import("./components/stocks/container/FinalDashboard"));

const ForexExchangeRate = lazy(() => import("./components/forex/container/ForexExchangeRate"));
const DailyForex = lazy(() => import("./components/forex/container/DailyForex"));
const MonthlyForex = lazy(() => import("./components/forex/container/MonthlyForex"));
const WeeklyForex = lazy(() => import("./components/forex/container/WeeklyForex"));
const MonthlyForexComparison = lazy(() => import("./components/forex/container/MonthlyForexComparison"));

const DynamicHighChart = lazy(() => import("./components/highcharts/container/DynamicHighChart"));

export default class MainLayout extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        let loading = "../images/loading.png";
        return (
            <div>
                <HighchartsMenu />
                <main>
                    <Suspense fallback={<div style={{ textAlign: "center", marginTop: "10%" }}>
                        <h5>Loading...</h5>
                    </div>}>
                        <Switch>
                            <Route path="/" component={DashboardHome} exact />
                            <Route path="/home" component={DashboardHome} exact />
                            <Route path="/stocks/daily" render={props => <DailyStock title={"Daily Stocks"} {...props} />} exact />
                            <Route path="/stocks/monthly/comparison" render={props => <MonthlyStockComparison title={"Monthly Stocks Comparison"} {...props} />} exact />
                            <Route path="/stocks/weekly" render={props =>
                                <WeeklyStock title={"Weekly Stocks"} {...props} />} exact />
                            <Route path="/stocks/monthly" render={props =>
                                <MonthlyStock title={"Monthly Stocks"} {...props} />} exact />
                            <Route path="/stocks/dashboard" render={props =>
                                <FinalDashboard title={"Stock Dashboard"} {...props} />} exact />
                            <Route path="/forex/rates" render={props =>
                                <ForexExchangeRate title={"Realtime Forex Exchange Rates"} {...props} />} exact />
                            <Route path="/forex/daily/rates" render={props =>
                                <DailyForex title={"Daily Forex Exchange Rates"} {...props} />} exact />
                            <Route path="/forex/weekly/rates" render={props =>
                                <WeeklyForex title={"Weekly Forex Exchange Rates"} {...props} />} exact />
                            <Route path="/forex/monthly/rates" render={props =>
                                <MonthlyForex title={"Monthly Forex Exchange Rates"} {...props} />} exact />
                            <Route path="/forex/monthly/comparison" render={props =>
                                <MonthlyForexComparison title={"Monthly Forex Exchange Rates Comparison"} {...props} />} exact />
                            <Route path="/highcharts/charts" render={props =>
                                <DynamicHighChart title={"Highcharts Chart with Drag & Drop Feature!"} subTitle={"Drag and Drop chart type name and see the changes!"} {...props} />} exact />
                            <Route path="**" render={props => <h1>Not Found Error!</h1>} />
                        </Switch>
                    </Suspense>
                </main>
            </div>
        )
    }
}
