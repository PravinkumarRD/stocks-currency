import React, { Component } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { Draggable, Droppable } from 'react-drag-and-drop';
import PropTypes from 'prop-types';
import { connect } from "react-redux";

import { getHighchartsData } from "../../../actions/highchart-actions";

class DynamicHighChart extends Component {
    constructor(props) {
        super(props);
        this.state = {
            chartType: "column",
            chartsList: ["area", "areaspline", "bar", "column", "line", "pie", "scatter"]
        }
        this.onDrop = this.onDrop.bind(this);
    }
    componentDidMount() {
        this.updateComponent();
    }
    updateComponent() {
        //http://localhost:9090/api/multiseries/chartsdata
        this.props.getHighchartsData("http://localhost:9090/api/multiseries/chartsdata");
    }
    render() {
        if (this.props.highchartsData.length > 0) {
            let chartCats = this.props.highchartsData[0].categories;
            const options = {
                chart: {
                    type: this.state.chartType
                },
                title: {
                    text: `Dynamic Chart with Drag and Drop Feature!`
                },
                xAxis: {
                    categories: chartCats
                },
                series: this.props.highchartsData
            };
            return (
                <div className="container-fluid">
                    <h1>{this.props.title}</h1>
                    <hr/>
                    <h6>{this.props.subTitle}</h6>
                    <br/>
                    <div className="container row">
                        <div className="col-md-2">
                            <table className="table">
                                <tbody>
                                    {
                                        this.state.chartsList.map((chart, idx) =>
                                            <tr key={idx}>
                                                <td>
                                                    <Draggable type="type" data={chart}>
                                                        {chart}
                                                    </Draggable></td>

                                            </tr>
                                        )
                                    }

                                </tbody>
                            </table>
                        </div>
                        <div className="col-md-9">
                            <Droppable
                                types={['type']}
                                onDrop={this.onDrop}>
                                <div>
                                    <HighchartsReact
                                        highcharts={Highcharts}
                                        options={options}
                                    />
                                </div>
                            </Droppable>
                        </div >
                    </div >
                </div >
            )
        }
        else {
            return <div style={{ textAlign: "center", marginTop: "10%" }}>
                <h5>Loading...</h5>
            </div>
        }
    }
    onDrop(data) {
        this.setState({
            chartType: data.type
        });
    }
}

DynamicHighChart.propTypes = {
    highchartsData: PropTypes.array.isRequired
}

const mapStateToProps = state => ({
    highchartsData: state.stockReducer.highchartsData
})

export default connect(mapStateToProps, { getHighchartsData })(DynamicHighChart);