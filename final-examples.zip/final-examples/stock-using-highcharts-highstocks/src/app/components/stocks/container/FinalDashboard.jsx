import React, { Component } from 'react';

import DailyStock from "./DailyStock";
import WeeklyStock from "./WeeklyStock";
import MonthlyStock from "./MonthlyStock";
import MonthlyStockComparison from "./MonthlyStockComparison";

export default class FinalDashboard extends Component {
    render() {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-6">
                        <DailyStock />
                    </div>
                    <div className="col-md-6">
                        <WeeklyStock />
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-12">
                        <DailyStock />
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-12">
                        <MonthlyStockComparison />
                    </div>
                </div>
            </div>
        )
    }
}
