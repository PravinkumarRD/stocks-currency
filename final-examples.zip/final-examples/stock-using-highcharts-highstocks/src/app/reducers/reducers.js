import { combineReducers } from "redux";

import stockReducer from "./highcharts-reducer";

export default combineReducers({
    stockReducer
});