import React, { Component, lazy, Suspense } from 'react';
import { Route, Switch } from "react-router-dom";

import HighchartsMenu from "./components/navigation/presentation/HighchartsMenu";
import DashboardHome from "./components/dashboards/container/DashboardHome";
const DailyStock = lazy(() => import("./components/stocks/container/DailyStock"));
const MonthlyStockComparison = lazy(() => import("./components/stocks/container/MonthlyStockComparison"));
const WeeklyStock = lazy(() => import("./components/stocks/container/WeeklyStock"));
const MonthlyStock = lazy(() => import("./components/stocks/container/MonthlyStock"));
const FinalDashboard = lazy(() => import("./components/stocks/container/FinalDashboard"));

export default class MainLayout extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        let loading = "../images/loading.png";
        return (
            <div>
                <HighchartsMenu />
                <main>
                    <Suspense fallback={<div style={{ textAlign: "center", marginTop: "10%" }}>
                        <h5>Loading...</h5>
                    </div>}>
                        <Switch>
                            <Route path="/" component={DashboardHome} exact />
                            <Route path="/home" component={DashboardHome} exact />
                            <Route path="/stocks/daily" render={props => <DailyStock title={"Daily Stocks"} {...props} />} exact />
                            <Route path="/stocks/monthly/comparison" render={props => <MonthlyStockComparison title={"Monthly Stocks Comparison"} {...props} />} exact />
                            <Route path="/stocks/weekly" render={props =>
                                <WeeklyStock title={"Weekly Stocks"} {...props} />} exact />
                            <Route path="/stocks/monthly" render={props =>
                                <MonthlyStock title={"Monthly Stocks"} {...props} />} exact />
                            <Route path="/stocks/dashboard" render={props =>
                                <FinalDashboard title={"Stock Dashboard"} {...props} />} exact />
                            <Route path="**" render={props => <h1>Not Found Error!</h1>} />
                        </Switch>
                    </Suspense>
                </main>
            </div>
        )
    }
}
