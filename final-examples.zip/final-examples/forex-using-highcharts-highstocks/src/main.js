import React from "react";
import ReactDOM from "react-dom";

import RootComponent from "./app/RootComponent";

ReactDOM.render(<RootComponent />, document.getElementById("container"));