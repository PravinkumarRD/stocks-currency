export default function (timeSeries) {
    let data = [], stock;
    for (var each in timeSeries) {
        stock = timeSeries[each];

        data.push([
            new Date(each).getTime(),
            parseFloat(stock["1. open"]),
            parseFloat(stock["2. high"]),
            parseFloat(stock["3. low"]),
            parseFloat(stock["4. close"])
        ]);
    }
    return data.reverse();
}

export function getExchangeData(rate) {
    let exchangeData = [];
    exchangeData.push([
        parseFloat(rate["8. Bid Price"]),
        parseFloat(rate["9. Ask Price"]),
        parseFloat(rate["5. Exchange Rate"])
    ]);
    return exchangeData;
}