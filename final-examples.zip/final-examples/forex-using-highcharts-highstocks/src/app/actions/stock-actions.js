import { STOCK_TIME_SERIES_DAILY, STOCK_TIME_SERIES_WEEKLY, STOCK_TIME_SERIES_MONTHLY, MULTIPLE_STOCK_SERIES_MONTHLY } from "./highcharts-action-types";

export const getStockTimeSeriesDaily = (symbol) => dispatch => {
    fetch(`https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&apikey=SH5VJ8C149PG8B7B&datatype=json`).then(
        response => response.json(),
        reason => Promise.reject(reason)
    ).then(
        stockData => dispatch({
            type: STOCK_TIME_SERIES_DAILY,
            payload: stockData
        }),
        reason => dispatch({
            type: STOCK_TIME_SERIES_DAILY,
            payload: reason
        })
    );
}

export const getStockTimeSeriesWeekly = (symbol) => dispatch => {
    fetch(`https://www.alphavantage.co/query?function=TIME_SERIES_WEEKLY&symbol=${symbol}&apikey=SH5VJ8C149PG8B7B&datatype=json`).then(
        response => response.json(),
        reason => Promise.reject(reason)
    ).then(
        stockData => dispatch({
            type: STOCK_TIME_SERIES_WEEKLY,
            payload: stockData
        }),
        reason => dispatch({
            type: STOCK_TIME_SERIES_WEEKLY,
            payload: reason
        })
    );
}

export const getStockTimeSeriesMonthly = (symbol) => dispatch => {
    fetch(`https://www.alphavantage.co/query?function=TIME_SERIES_MONTHLY&symbol=${symbol}&apikey=SH5VJ8C149PG8B7B&datatype=json`).then(
        response => response.json(),
        reason => Promise.reject(reason)
    ).then(
        stockData => dispatch({
            type: STOCK_TIME_SERIES_MONTHLY,
            payload: stockData
        }),
        reason => dispatch({
            type: STOCK_TIME_SERIES_MONTHLY,
            payload: reason
        })
    );
}

export const getMonthlyStocksForComparison = (...symbols) => dispatch => {
    const monthlyStocksData = [];
    Promise.all(symbols.map(symbol =>
        fetch(`https://www.alphavantage.co/query?function=TIME_SERIES_MONTHLY&symbol=${symbol}&apikey=SH5VJ8C149PG8B7B&datatype=json`).then(
            response => response.json(),
            reason => Promise.reject(reason)
        ).then(
            stockData => stockData,
            reason => dispatch({
                type: MULTIPLE_STOCK_SERIES_MONTHLY,
                payload: reason
            })
        )
    ))
        .then(data => {
            dispatch({
                type: MULTIPLE_STOCK_SERIES_MONTHLY,
                payload: data
            });
        })
}
// , () => dispatch({
//     type: MULTIPLE_STOCK_SERIES_MONTHLY,
//     payload: { ...monthlyStocksData }
// })
