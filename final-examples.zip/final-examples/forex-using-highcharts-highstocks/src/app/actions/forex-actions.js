import { FX_EXCHANGE_RATES, FX_DAILY, FX_WEEKLY, FX_MONTHLY, MULTIPLE_EXCHANGE_SERIES_MONTHLY } from "./highcharts-action-types";

export const getForexExchangeRates = (fromCountrySymbol, ...toCountriesSymbol) => dispatch => {
    Promise.all(toCountriesSymbol.map(symbol =>
        fetch(`https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE&from_currency=${fromCountrySymbol}&to_currency=${symbol}&apikey=SH5VJ8C149PG8B7B`).then(
            response => response.json(),
            reason => Promise.reject(reason)
        ).then(
            exchangeData => exchangeData,
            reason => dispatch({
                type: FX_EXCHANGE_RATES,
                payload: reason
            })
        )
    ))
        .then(data => {
            dispatch({
                type: FX_EXCHANGE_RATES,
                payload: data
            });
        })
}

export const getExchangeTimeSeriesDaily = (fromCountrySymbol, toCountriesSymbol) => dispatch => {
    fetch(`https://www.alphavantage.co/query?function=FX_DAILY&from_symbol=${fromCountrySymbol}&to_symbol=${toCountriesSymbol}&apikey=SH5VJ8C149PG8B7B&datatype=json`).then(
        response => response.json(),
        reason => Promise.reject(reason)
    ).then(
        exchangeData => dispatch({
            type: FX_DAILY,
            payload: exchangeData
        }),
        reason => dispatch({
            type: FX_DAILY,
            payload: reason
        })
    );
}

export const getExchangeTimeSeriesWeekly = (fromCountrySymbol, toCountriesSymbol) => dispatch => {
    fetch(`https://www.alphavantage.co/query?function=FX_WEEKLY&from_symbol=${fromCountrySymbol}&to_symbol=${toCountriesSymbol}&apikey=SH5VJ8C149PG8B7B&datatype=json`).then(
        response => response.json(),
        reason => Promise.reject(reason)
    ).then(
        exchangeData => dispatch({
            type: FX_WEEKLY,
            payload: exchangeData
        }),
        reason => dispatch({
            type: FX_WEEKLY,
            payload: reason
        })
    );
}

export const getExchangeTimeSeriesMonthly = (fromCountrySymbol, toCountriesSymbol) => dispatch => {
    fetch(`https://www.alphavantage.co/query?function=FX_MONTHLY&from_symbol=${fromCountrySymbol}&to_symbol=${toCountriesSymbol}&apikey=SH5VJ8C149PG8B7B&datatype=json`).then(
        response => response.json(),
        reason => Promise.reject(reason)
    ).then(
        exchangeData => dispatch({
            type: FX_MONTHLY,
            payload: exchangeData
        }),
        reason => dispatch({
            type: FX_MONTHLY,
            payload: reason
        })
    );
}

export const getMonthlyExchangeForComparison = (fromCountrySymbol, ...toCountriesSymbol) => dispatch => {
    Promise.all(toCountriesSymbol.map(countryCurrency =>
        fetch(`https://www.alphavantage.co/query?function=FX_MONTHLY&from_symbol=${fromCountrySymbol}&to_symbol=${countryCurrency}&apikey=SH5VJ8C149PG8B7B&datatype=json`).then(
            response => response.json(),
            reason => Promise.reject(reason)
        ).then(
            exchangeData => exchangeData,
            reason => dispatch({
                type: MULTIPLE_EXCHANGE_SERIES_MONTHLY,
                payload: reason
            })
        )
    ))
        .then(data => {
            dispatch({
                type: MULTIPLE_EXCHANGE_SERIES_MONTHLY,
                payload: data
            });
        })
}