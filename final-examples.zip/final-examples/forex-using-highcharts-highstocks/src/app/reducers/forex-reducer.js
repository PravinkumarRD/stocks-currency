import { FX_DAILY, FX_WEEKLY, FX_MONTHLY, FX_EXCHANGE_RATES, MULTIPLE_EXCHANGE_SERIES_MONTHLY } from "../actions/highcharts-action-types";

const initialState = {
    dailyExchangeRates: {},
    weeklyExchangeRates: {},
    monthlyExchangeRates: {},
    exchangeRates: [],
    exchangeRatesComparison: []
}

export default function (state = initialState, action) {
    switch (action.type) {
        case FX_DAILY:
            state = {
                ...state,
                dailyExchangeRates: action.payload
            }
            break;
        case FX_WEEKLY:
            state = {
                ...state,
                weeklyExchangeRates: action.payload
            }
            break;

        case FX_MONTHLY:
            state = {
                ...state,
                monthlyExchangeRates: action.payload
            }
            break;
        case FX_EXCHANGE_RATES:
            state = {
                ...state,
                exchangeRates: action.payload
            }
            break;
        case MULTIPLE_EXCHANGE_SERIES_MONTHLY:
            state = {
                ...state,
                exchangeRatesComparison: action.payload
            }
            break;
    }
    return state;
}