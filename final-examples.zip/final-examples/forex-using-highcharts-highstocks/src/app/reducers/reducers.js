import { combineReducers } from "redux";

import stockReducer from "./highcharts-reducer";
import forexReducer from "./forex-reducer";

export default combineReducers({
    stockReducer,
    forexReducer
});