import { createStore, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import { logger } from "redux-logger";

import sepReducers from "../reducers/sep-reducers";

const middlewares = [
    thunk,
    logger
];
const initialState = {};

const SepStore = createStore(sepReducers, initialState, applyMiddleware(...middlewares));

export default SepStore;