import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

import getSeriesData, { getExchangeData } from "../../../utilities/global-functions";
import { getForexExchangeRates } from "../../../actions/forex-actions";

class ForexExchangeRate extends Component {
    constructor(props) {
        super(props);
        this.state = {
            exchangeOf: ["USD", "EUR", "AED", "INR"]
        }
    }
    componentDidMount() {
        this.props.getForexExchangeRates("JPY", ...this.state.exchangeOf);
    }
    render() {
        if (this.props.exchangeRates.length > 0) {
            var seriesOptions = [];
            for (let i = 0; i < this.props.exchangeRates.length; i++) {
                const rate = this.props.exchangeRates[i];
                console.log(rate)
                seriesOptions[i] = {
                    name: this.state.exchangeOf[i],
                    data: getExchangeData(rate["Realtime Currency Exchange Rate"])
                }
            }
            console.log(seriesOptions);
            const options = {
                chart: {
                    type: 'column'
                },
                title: {
                    text: `Realtime Exchange Rate of ${this.state.exchangeOf}`
                },
                xAxis: {
                    categories: [...this.state.exchangeOf]
                },
                yAxis: {
                    title: {
                        text: 'Realtime Exchange Rates'
                    }
                },
                legend: {
                    reversed: true
                },
                plotOptions: {
                    series: {
                        stacking: 'normal'
                    }
                },
                series: seriesOptions
            };
            return (
                <div>
                    <h1>{this.props.title}</h1>
                    <HighchartsReact
                        highcharts={Highcharts}
                        options={options}
                    />
                </div>
            )
        }
        else {
            return <div style={{ textAlign: "center", marginTop: "10%" }}>
                <h5>Loading...</h5>
            </div>
        }
    }
}
ForexExchangeRate.propTypes = {
    exchangeRates: PropTypes.array.isRequired
}

const mapStateToProps = function (state) {
    return ({ exchangeRates: state.forexReducer.exchangeRates })
}

export default connect(mapStateToProps, { getForexExchangeRates })(ForexExchangeRate);