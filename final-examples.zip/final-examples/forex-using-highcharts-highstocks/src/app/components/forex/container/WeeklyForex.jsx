import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';

import { getExchangeTimeSeriesWeekly } from "../../../actions/forex-actions";
import getSeriesData from "../../../utilities/global-functions";

class WeeklyForex extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {
        this.props.getExchangeTimeSeriesWeekly("USD","INR");
    }

    render() {
        if (this.props.weeklyExchangeRates) {
            let exchangeSeriesData = getSeriesData(this.props.weeklyExchangeRates['Time Series FX (Weekly)']);

            const options = {
                chart: {
                    type: 'line'
                },
                title: {
                    text: 'Weekly Exchange Rate of (INR)'
                },
                rangeSelector: {
                    selected: 6
                },
                series: [
                    {
                        name: 'INR',
                        data: exchangeSeriesData
                    }
                ]
            };
            return (
                <div>
                    <h1>{this.props.title}</h1>
                    <HighchartsReact
                        highcharts={Highcharts}
                        constructorType={'stockChart'}
                        options={options}
                    />
                </div>
            )
        }
        else {
            return <div style={{textAlign:"center",marginTop:"10%"}}>
                <h5>Loading...</h5>
            </div>
        }
    }
}
WeeklyForex.propTypes = {
    weeklyExchangeRates: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    weeklyExchangeRates: state.forexReducer.weeklyExchangeRates
})

export default connect(mapStateToProps, { getExchangeTimeSeriesWeekly })(WeeklyForex);