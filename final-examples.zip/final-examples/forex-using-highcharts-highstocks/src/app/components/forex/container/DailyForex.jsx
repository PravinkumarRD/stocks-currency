import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';

import { getExchangeTimeSeriesDaily } from "../../../actions/forex-actions";
import getSeriesData from "../../../utilities/global-functions";

class DailyForex extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {
        this.props.getExchangeTimeSeriesDaily("USD","INR");
    }

    render() {
        if (this.props.dailyExchangeRates) {
            let exchangeSeriesData = getSeriesData(this.props.dailyExchangeRates['Time Series FX (Daily)']);

            const options = {
                chart: {
                    type: 'line'
                },
                title: {
                    text: 'Daily Exchange Rate of (INR)'
                },
                rangeSelector: {
                    selected: 6
                },
                series: [
                    {
                        name: 'INR',
                        data: exchangeSeriesData
                    }
                ]
            };
            return (
                <div>
                    <h1>{this.props.title}</h1>
                    <HighchartsReact
                        highcharts={Highcharts}
                        constructorType={'stockChart'}
                        options={options}
                    />
                </div>
            )
        }
        else {
            return <div style={{textAlign:"center",marginTop:"10%"}}>
                <h5>Loading...</h5>
            </div>
        }
    }
}
DailyForex.propTypes = {
    dailyExchangeRates: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    dailyExchangeRates: state.forexReducer.dailyExchangeRates
})

export default connect(mapStateToProps, { getExchangeTimeSeriesDaily })(DailyForex);