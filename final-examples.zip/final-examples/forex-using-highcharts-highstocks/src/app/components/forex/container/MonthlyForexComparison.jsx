import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';

import getSeriesData from "../../../utilities/global-functions";
import { getMonthlyExchangeForComparison } from "../../../actions/forex-actions";

class MonthlyExchangeComparison extends Component {
    constructor(props) {
        super(props);
        this.state = {
            exchangeOf: ["AED", "GBP", "INR", "JPY"]
        }
    }
    componentDidMount() {
        this.props.getMonthlyExchangeForComparison("USD", ...this.state.exchangeOf);
    }
    render() {
        //type: 'candlestick' or 'ohlc'
        if (this.props.exchangeRatesComparison.length > 0) {
            var seriesOptions = [];
            for (let i = 0; i < this.props.exchangeRatesComparison.length; i++) {
                const exchange = this.props.exchangeRatesComparison[i];
                seriesOptions[i] = {
                    name: this.state.exchangeOf[i],
                    data: getSeriesData(exchange['Time Series FX (Monthly)'])
                }
            }
            const options = {
                title: {
                    text: `Monthly Exchange Rates of ${this.state.exchangeOf}`
                },
                rangeSelector: {
                    selected: 3
                },

                plotOptions: {
                    series: {
                        compare: 'percent'
                    }
                },
                series: seriesOptions
            };
            return (
                <div>
                    <h1>{this.props.title}</h1>
                    <HighchartsReact
                        highcharts={Highcharts}
                        constructorType={'stockChart'}
                        options={options}
                    />
                </div>
            )
        }
        else {
            return <div style={{ textAlign: "center", marginTop: "10%" }}>
                <h5>Loading...</h5>
            </div>
        }
    }
}
MonthlyExchangeComparison.propTypes = {
    exchangeRatesComparison: PropTypes.array.isRequired
}

const mapStateToProps = function (state) {
    return ({ exchangeRatesComparison: state.forexReducer.exchangeRatesComparison })
}

export default connect(mapStateToProps, { getMonthlyExchangeForComparison })(MonthlyExchangeComparison);