import React, { Component } from 'react';

export default class DashboardHome extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return <h1>Welcome To React-Redux Dashboard Home!!!</h1>
    }
}