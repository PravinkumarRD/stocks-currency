import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';

import { getStockTimeSeriesWeekly } from "../../../actions/stock-actions";
import getSeriesData from "../../../utilities/global-functions";

class WeeklyStock extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount() {
        this.props.getStockTimeSeriesWeekly("MSFT");
    }

    render() {
        if (this.props.weeklyStocks) {
            let stockSeriesData = getSeriesData(this.props.weeklyStocks['Weekly Time Series']);
            console.log(stockSeriesData);
            const options = {
                title: {
                    text: 'Weekly Stocks of MSFT'
                },
                rangeSelector: {
                    selected: 6
                },
                series: [
                    {
                        name: 'MSFT',
                        data: stockSeriesData
                    }
                ]
            };
            return (
                <div>
                    <h1>{this.props.title}</h1>
                    <HighchartsReact
                        highcharts={Highcharts}
                        constructorType={'stockChart'}
                        options={options}
                    />
                </div>
            )
        }
        else {
            return <div style={{ textAlign: "center", marginTop: "10%" }}>
                <h5>Loading...</h5>
            </div>
        }
    }
}
WeeklyStock.propTypes = {
    weeklyStocks: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
    weeklyStocks: state.stockReducer.weeklyStocks
})

export default connect(mapStateToProps, { getStockTimeSeriesWeekly })(WeeklyStock);